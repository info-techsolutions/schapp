<?php
$myTitle = 'Showing All Class - MYSCHOOL APP';

// include_once '../pages/header.php';
include_once '../inc/config.php';
include_once '../inc/errorcode.php';
// include_once '../inc/function.php';

if (isset($_POST)) {

    $sessions = $_POST["sessions"];
    $terms = $_POST["terms"];
   // $tests = $_POST["tests"];
  //$subjects = $_POST["subjects"];
    $classes = $_POST["classes"];
  //  $arms = $_POST["arms"];
    ?>
    
    <table id="example" class="ui celled table" cellspacing="0" width="100%">	
	<thead>
            <tr>
                <th>S/N</th>
                <th>Admission Number</th>
                <th>Action</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>S/N</th>
                <th>Admission Number</th>
                <th>Action</th>
            </tr>
        </tfoot>
         
     
        <tbody>
    <?php
    $r = 1;
    $stmt = $db->query("SELECT z_tb_person.person_number, z_tb_session.year AS session_year,
     z_tb_term.name AS term_name, z_tb_class.name AS class_name
    FROM z_tb_person, z_tb_session, z_tb_term, z_tb_class WHERE 
    z_tb_session.session_id = '$sessions'
    AND z_tb_term.term_id = '$terms'
    AND z_tb_person.class_id = z_tb_class.class_id AND z_tb_person.class_id = '$classes' AND typ = 'STUDENT'");
    
foreach($stmt as $row){	
	
              ?>
                    <tr>
                        <td><?php echo $r; ?></td>
                        <td><?php echo $row["person_number"];  ?></td>
                        
                        <td>
                            

                        </td>
                    </tr>
                    <?php
                    $r++;
                }
                       
            ?>
        </tbody>
    </table>
    <?php
  
 }
